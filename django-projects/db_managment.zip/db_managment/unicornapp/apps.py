from django.apps import AppConfig


class UnicornappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'unicornapp'
